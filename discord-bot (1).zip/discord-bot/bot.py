import os
import json
import aiohttp
import discord
from discord.ext import commands, tasks
from discord import app_commands
from dotenv import load_dotenv
from pathlib import Path

load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")
# Optional: channel ID where update alerts will be posted
ALERT_CHANNEL_ID = os.getenv("ALERT_CHANNEL_ID")  # set this in .env if you want auto alerts

if not TOKEN:
    raise ValueError("DISCORD_TOKEN not found. Please set it in your .env file.")

# WEAO API
WEAO_BASE = "https://weao.xyz/api/status/exploits"
USER_AGENT = "WEAO-3PService"
HEADERS = {"User-Agent": USER_AGENT}

# Local cache file so we can detect changes across restarts
CACHE_FILE = Path("executor_cache.json")

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)


# ====================== Helpers ======================

async def fetch_all_executors() -> list[dict]:
    """Fetch the full list of executors from WEAO."""
    async with aiohttp.ClientSession(headers=HEADERS) as session:
        async with session.get(WEAO_BASE, timeout=15) as resp:
            if resp.status != 200:
                raise Exception(f"WEAO API returned {resp.status}")
            return await resp.json()


async def fetch_executor(name: str) -> dict | None:
    """Fetch a single executor by name (case-insensitive)."""
    async with aiohttp.ClientSession(headers=HEADERS) as session:
        # Try exact name first
        url = f"{WEAO_BASE}/{name}"
        async with session.get(url, timeout=10) as resp:
            if resp.status == 200:
                return await resp.json()

        # Fallback: search in full list
        data = await fetch_all_executors()
        for exe in data:
            if exe.get("title", "").lower() == name.lower():
                return exe
            # also try without spaces / special chars
            if exe.get("title", "").lower().replace(" ", "") == name.lower().replace(" ", ""):
                return exe
    return None


def load_cache() -> dict:
    if CACHE_FILE.exists():
        try:
            return json.loads(CACHE_FILE.read_text())
        except Exception:
            return {}
    return {}


def save_cache(data: dict):
    CACHE_FILE.write_text(json.dumps(data, indent=2))


def make_executor_embed(exe: dict) -> discord.Embed:
    """Create a rich embed for an executor."""
    title = exe.get("title", "Unknown")
    version = exe.get("version", "N/A")
    updated = exe.get("updatedDate", "Unknown")
    free = exe.get("free", False)
    detected = exe.get("detected", False)
    updated_status = exe.get("updateStatus", False)
    platform = exe.get("platform", "Unknown")
    cost = exe.get("cost", "Free" if free else "Paid")
    unc = exe.get("uncPercentage")
    sunc = exe.get("suncPercentage")
    decompiler = exe.get("decompiler", False)
    multi = exe.get("multiInject", False)
    website = exe.get("websitelink")
    discord_link = exe.get("discordlink")
    purchase = exe.get("purchaselink")
    rbx = exe.get("rbxversion", "N/A")
    logo = None
    description = None

    slug = exe.get("slug") or {}
    if isinstance(slug, dict):
        logo = slug.get("logo")
        description = slug.get("fullDescription")

    # Status colors
    color = discord.Color.green() if updated_status else discord.Color.red()
    if detected:
        color = discord.Color.orange()

    embed = discord.Embed(
        title=f"{title}  •  v{version}",
        color=color,
        timestamp=discord.utils.utcnow()
    )

    # Status line
    status_emoji = "✅ Updated" if updated_status else "❌ Not Updated"
    detect_emoji = "⚠️ Detected" if detected else "🟢 Undetected"
    free_emoji = "🆓 Free" if free else f"💰 {cost}"

    embed.add_field(name="Status", value=status_emoji, inline=True)
    embed.add_field(name="Detection", value=detect_emoji, inline=True)
    embed.add_field(name="Price", value=free_emoji, inline=True)

    embed.add_field(name="Platform", value=platform, inline=True)
    embed.add_field(name="Last Updated", value=updated, inline=True)
    embed.add_field(name="Roblox Version", value=f"`{rbx}`", inline=True)

    # Features
    features = []
    if decompiler:
        features.append("Decompiler")
    if multi:
        features.append("Multi-Inject")
    if exe.get("clientmods"):
        features.append("Client Mods")
    if exe.get("raknet"):
        features.append("RakNet")
    if features:
        embed.add_field(name="Features", value=", ".join(features), inline=False)

    # UNC / sUNC scores
    scores = []
    if unc is not None:
        scores.append(f"UNC: **{unc}%**")
    if sunc is not None:
        scores.append(f"sUNC: **{sunc}%**")
    if scores:
        embed.add_field(name="Compatibility", value=" • ".join(scores), inline=False)

    # Links
    links = []
    if website:
        links.append(f"[Website]({website})")
    if discord_link:
        links.append(f"[Discord]({discord_link})")
    if purchase:
        links.append(f"[Purchase]({purchase})")
    if links:
        embed.add_field(name="Links", value=" • ".join(links), inline=False)

    if description and len(description) < 800:
        embed.add_field(name="Description", value=description[:800], inline=False)

    if logo:
        embed.set_thumbnail(url=logo)

    embed.set_footer(text="Data from weao.xyz • Use !executors for full list")
    return embed


# ====================== Events ======================

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} (ID: {bot.user.id})")
    print("------")
    try:
        synced = await bot.tree.sync()
        print(f"Synced {len(synced)} slash command(s)")
    except Exception as e:
        print(f"Failed to sync slash commands: {e}")

    # Start the automatic checker
    if not check_executor_updates.is_running():
        check_executor_updates.start()
        print("Automatic executor update checker started.")


# ====================== Automatic Checker ======================

@tasks.loop(minutes=5)  # check every 5 minutes
async def check_executor_updates():
    """Background task that detects when an executor gets updated."""
    try:
        current = await fetch_all_executors()
        previous = load_cache()

        changes = []
        new_cache = {}

        for exe in current:
            title = exe.get("title")
            if not title:
                continue

            key = title.lower()
            version = exe.get("version")
            updated_status = exe.get("updateStatus", False)
            updated_date = exe.get("updatedDate")

            new_cache[key] = {
                "version": version,
                "updateStatus": updated_status,
                "updatedDate": updated_date,
                "title": title
            }

            old = previous.get(key)
            if old is None:
                # first time seeing it – don't spam
                continue

            # Detect meaningful changes
            if old.get("version") != version:
                changes.append(f"**{title}** updated to version `{version}`")
            elif old.get("updateStatus") is False and updated_status is True:
                changes.append(f"**{title}** is now **Updated** ✅ (v{version})")
            elif old.get("updateStatus") is True and updated_status is False:
                changes.append(f"**{title}** is no longer updated ❌")

        save_cache(new_cache)

        if changes and ALERT_CHANNEL_ID:
            channel = bot.get_channel(int(ALERT_CHANNEL_ID))
            if channel:
                embed = discord.Embed(
                    title="🔄 Executor Update Detected",
                    description="\n".join(changes),
                    color=discord.Color.blue(),
                    timestamp=discord.utils.utcnow()
                )
                embed.set_footer(text="Automatic checker • weao.xyz")
                await channel.send(embed=embed)

    except Exception as e:
        print(f"[Checker] Error: {e}")


@check_executor_updates.before_loop
async def before_checker():
    await bot.wait_until_ready()


# ====================== Prefix Commands ======================

@bot.command(name="executors", aliases=["list", "exes"])
async def list_executors(ctx: commands.Context):
    """Show a list of all tracked executors and their status."""
    async with ctx.typing():
        try:
            data = await fetch_all_executors()
        except Exception as e:
            await ctx.send(f"❌ Failed to fetch data: `{e}`")
            return

        # Sort: updated first, then by name
        data.sort(key=lambda x: (not x.get("updateStatus", False), x.get("title", "").lower()))

        lines = []
        for exe in data:
            if exe.get("hidden"):
                continue
            title = exe.get("title", "?")
            status = "✅" if exe.get("updateStatus") else "❌"
            free = "🆓" if exe.get("free") else "💰"
            detected = "⚠️" if exe.get("detected") else ""
            lines.append(f"{status} {free} **{title}** {detected}")

        # Split into chunks if too long
        embed = discord.Embed(
            title="📋 Executor List",
            description="\n".join(lines[:40]),  # limit
            color=discord.Color.blurple()
        )
        embed.set_footer(text=f"Showing {min(40, len(lines))} executors • Use !name for details (e.g. !solara)")
        await ctx.send(embed=embed)


@bot.command(name="check")
async def check_executor(ctx: commands.Context, *, name: str = None):
    """Check status of a specific executor. Usage: !check Solara"""
    if not name:
        await ctx.send("Usage: `!check <executor name>`  (example: `!check Solara`)")
        return

    async with ctx.typing():
        exe = await fetch_executor(name)
        if not exe:
            await ctx.send(f"❌ Could not find executor named **{name}**.\nTry `!executors` to see the full list.")
            return
        embed = make_executor_embed(exe)
        await ctx.send(embed=embed)


# Dynamic command for popular ones + catch-all style via on_message alternative
# We make a flexible command that works as !solara, !wave, etc.

@bot.command(name="solara")
async def solara_cmd(ctx):
    await check_executor(ctx, name="Solara")

@bot.command(name="wave")
async def wave_cmd(ctx):
    await check_executor(ctx, name="Wave")

@bot.command(name="potassium")
async def potassium_cmd(ctx):
    await check_executor(ctx, name="Potassium")

@bot.command(name="codex")
async def codex_cmd(ctx):
    await check_executor(ctx, name="Codex")

@bot.command(name="sirhurt")
async def sirhurt_cmd(ctx):
    await check_executor(ctx, name="SirHurt")

@bot.command(name="cosmic")
async def cosmic_cmd(ctx):
    await check_executor(ctx, name="Cosmic")

@bot.command(name="real")
async def real_cmd(ctx):
    await check_executor(ctx, name="Real")

@bot.command(name="photon")
async def photon_cmd(ctx):
    await check_executor(ctx, name="Photon")

@bot.command(name="ronin")
async def ronin_cmd(ctx):
    await check_executor(ctx, name="Ronin")


# Catch-all for any other name: !anyname
@bot.event
async def on_message(message: discord.Message):
    if message.author.bot:
        return

    # Let normal commands work first
    await bot.process_commands(message)

    # If the message is just "!something" and no command matched, try treating it as executor name
    content = message.content.strip()
    if content.startswith("!") and len(content) > 1 and " " not in content:
        name = content[1:]
        # Skip if it already is a registered command
        if bot.get_command(name.lower()):
            return
        # Try to fetch it
        ctx = await bot.get_context(message)
        await check_executor(ctx, name=name)


# ====================== Slash Commands ======================

@bot.tree.command(name="executors", description="List all tracked executors")
async def slash_executors(interaction: discord.Interaction):
    await interaction.response.defer()
    try:
        data = await fetch_all_executors()
    except Exception as e:
        await interaction.followup.send(f"❌ Failed to fetch data: `{e}`")
        return

    data.sort(key=lambda x: (not x.get("updateStatus", False), x.get("title", "").lower()))
    lines = []
    for exe in data:
        if exe.get("hidden"):
            continue
        title = exe.get("title", "?")
        status = "✅" if exe.get("updateStatus") else "❌"
        free = "🆓" if exe.get("free") else "💰"
        detected = "⚠️" if exe.get("detected") else ""
        lines.append(f"{status} {free} **{title}** {detected}")

    embed = discord.Embed(
        title="📋 Executor List",
        description="\n".join(lines[:40]),
        color=discord.Color.blurple()
    )
    embed.set_footer(text="Use /check name:Solara for details")
    await interaction.followup.send(embed=embed)


@bot.tree.command(name="check", description="Check status of a specific executor")
@app_commands.describe(name="Name of the executor (e.g. Solara, Wave)")
async def slash_check(interaction: discord.Interaction, name: str):
    await interaction.response.defer()
    exe = await fetch_executor(name)
    if not exe:
        await interaction.followup.send(f"❌ Could not find executor named **{name}**.")
        return
    embed = make_executor_embed(exe)
    await interaction.followup.send(embed=embed)


# ====================== Run ======================

if __name__ == "__main__":
    bot.run(TOKEN)
