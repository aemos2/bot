# Discord Executor Status Bot

A Discord bot that shows live Roblox executor status using the **weao.xyz** API.

## Features

### Executor Commands
| Command | Description |
|---------|-------------|
| `!solara` / `!wave` / `!potassium` / etc. | Shows detailed info about that executor |
| `!check <name>` | Check any executor by name |
| `!executors` or `!list` | Full list of all tracked executors |
| `/check` and `/executors` | Slash command versions |

Just type `!solara`, `!wave`, `!codex`, `!sirhurt`, `!cosmic`, `!real`, `!photon`, `!ronin` or any other name.

### Automatic Checker
- Runs every **5 minutes** in the background
- Detects when an executor:
  - Gets a new version
  - Changes from "Not Updated" → "Updated"
  - Goes offline / becomes outdated
- Sends an alert embed to the channel you set in `.env`

## Setup

### 1. Discord Bot
1. Go to [Discord Developer Portal](https://discord.com/developers/applications)
2. Create an application → Bot tab → copy the token
3. Enable **Message Content Intent**
4. Invite the bot with `bot` + `applications.commands` scopes

### 2. Install
```bash
python -m venv venv
# Windows: venv\Scripts\activate
# Linux/Mac: source venv/bin/activate

pip install -r requirements.txt
```

### 3. Config
Copy `.env.example` → `.env` and fill in:

```
DISCORD_TOKEN=your_token_here
ALERT_CHANNEL_ID=123456789012345678   # optional – for auto alerts
```

### 4. Run
```bash
python bot.py
```

## Example Output

`!solara` shows a rich embed with:
- Version & last updated date
- Updated / Detected status
- Free or price
- Platform, UNC % / sUNC %
- Features (Decompiler, Multi-Inject, etc.)
- Website / Discord / Purchase links
- Description + logo

## Notes
- Data comes from [weao.xyz](https://weao.xyz)
- The automatic checker only posts when something actually changes
- Cache is saved locally in `executor_cache.json` so it works across restarts
